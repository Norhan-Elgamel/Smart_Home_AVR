/*
**************************** Author  : Mohamed Adel *****************************
**************************** Module  : DIO Driver   *****************************
**************************** Date    : 9/05/2021    *****************************
**************************** Version : 2.0          *****************************
*/
#ifndef DIO_INTERFACE_H
#define DIO_INTERFACE_H
#include"STD_TYPES.h"
//Registers macros
#define DIO_u8_PORTA      0
#define DIO_u8_PORTB      1
#define DIO_u8_PORTC      2
#define DIO_u8_PORTD      3

//Pins macros
#define DIO_u8_PIN0       0
#define DIO_u8_PIN1       1
#define DIO_u8_PIN2       2
#define DIO_u8_PIN3       3
#define DIO_u8_PIN4       4
#define DIO_u8_PIN5       5
#define DIO_u8_PIN6       6
#define DIO_u8_PIN7       7

//Other macros
#define DIO_u8_LOW        0
#define DIO_u8_HIGH       1
 
#define DIO_u8_INPUT      0
#define DIO_u8_OUTPUT     1



// dealing with pins
u8 DIO_u8SetPinDirection(u8 copy_u8PortId, u8 copy_u8PinId, u8 copy_u8PinDirection);
u8 DIO_u8SetPinValue(u8 copy_u8PortId, u8 copy_u8PinId, u8 copy_u8PinValue);
u8 DIO_u8GetPinValue(u8 copy_u8PortId, u8 copy_u8PinId, u8 * copy_pu8PinValue);

//dealing with ports
u8 DIO_u8SetPortDirection(u8 copy_u8PortId, u8 copy_u8PortDirection);
u8 DIO_u8SetPortValue(u8 copy_u8PortId, u8 copy_u8PortValue);
u8 DIO_u8GetPortValue(u8 copy_u8PortId, u8 * copy_pu8PortValue);


#endif
