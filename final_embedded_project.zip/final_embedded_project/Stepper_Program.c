/***************************************************************************************/
/****************************  IMT School Training Center ******************************/
/***************************************************************************************/
/** This file is developed by IMT School training center, All copyrights are reserved **/
/***************************************************************************************/
#ifndef F_CPU
#define F_CPU 8000000UL
#endif

/****************************************************/
/* Header files Inclusions						    */
/****************************************************/
#include <util/delay.h>
#include "STD_TYPES.h"
#include "BIT_MATH.h"

#include "DIO_Interface.h"
#include "DIO_Private.h"
#include "DIO_Config.h"

#include "Stepper_Interface.h"
#include "Stepper_Config.h"

/*********************************************************************************/
/* Function: STP_voidInit			                        				    */
/* Desc: This function initializes the stepper motor pins as outputs            */
/*********************************************************************************/
void STP_voidInit(void)
{
	// Configure direction of pins as output
	DIO_u8SetPortDirection(STP_u8_PORT, 0xFF);

	// Initialize their values to HIGH (motor off)
	DIO_u8SetPortValue(STP_u8_PORT, 0xFF);
}

/*********************************************************************************/
/* Function: STP_voidMove			                        				    */
/* Desc: This function moves the stepper motor in clockwise or counter-clockwise */
/* Copy_u8Direction Options: CLOCKWISE_DIRECTION, COUNTER_CLOCKWISE_DIRECTION    */
/*********************************************************************************/
void STP_voidMove(u8 Copy_u8Direction)
{
	switch (Copy_u8Direction)
	{
		case COUNTER_CLOCKWISE_DIRECTION:
			// Step 1
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN0, DIO_u8_LOW);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN1, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN2, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN3, DIO_u8_HIGH);
			_delay_ms(10);

			// Step 2
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN0, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN1, DIO_u8_LOW);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN2, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN3, DIO_u8_HIGH);
			_delay_ms(10);

			// Step 3
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN0, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN1, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN2, DIO_u8_LOW);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN3, DIO_u8_HIGH);
			_delay_ms(10);

			// Step 4
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN0, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN1, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN2, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN3, DIO_u8_LOW);
			_delay_ms(10);
			break;

		case CLOCKWISE_DIRECTION:
			// Step 4
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN0, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN1, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN2, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN3, DIO_u8_LOW);
			_delay_ms(10);

			// Step 3
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN0, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN1, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN2, DIO_u8_LOW);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN3, DIO_u8_HIGH);
			_delay_ms(10);

			// Step 2
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN0, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN1, DIO_u8_LOW);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN2, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN3, DIO_u8_HIGH);
			_delay_ms(10);

			// Step 1
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN0, DIO_u8_LOW);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN1, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN2, DIO_u8_HIGH);
			DIO_u8SetPinValue(DIO_u8_PORTA, DIO_u8_PIN3, DIO_u8_HIGH);
			_delay_ms(10);
			break;
	}
}
