/*

# include <avr/io.h>
#include <util/delay.h>
send_cmd(u8 x){
	 CLR_BIT(PORTC,0); // RS=0
	 CLR_BIT(PORTC,1);//R/W=0
	 PORTD=0b0000 00001;
	 SET_BIT(PORTC,2); //E=1
	 CLR_BIT(PORTC,2); //E=0

} */

/*#include"BIT_MATH.h"
#include"STD_TYPES.h"
#include"DIO_interface.h"
#include"LCD_interface.h"

int main(){
	LCD_voidInit();
	LCD_u8SetPosition(LCD_u8_LINE1,1);
	LCD_voidSendString("Norhan Ahmed");
	LCD_u8SetPosition(LCD_u8_LINE2,0);
	LCD_voidSendString("24-101390 ");
	while(1){

	}
}*/
