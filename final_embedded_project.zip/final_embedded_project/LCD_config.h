/*
**************************** Author  : Mohamed Adel *****************************
**************************** Module  : LCD Driver   *****************************
**************************** Date    : 9/05/2021    *****************************
**************************** Version : 2.0          *****************************
*/
#ifndef LCD_CONFIG_H
#define LCD_CONFIG_H

//to not edit in the source code
#define   LCD_u8_CONTROL_PORT     DIO_u8_PORTB
#define   LCD_u8_RS_PIN           DIO_u8_PIN0
#define   LCD_u8_RW_PIN           DIO_u8_PIN1
#define   LCD_u8_E_PIN            DIO_u8_PIN2

#define   LCD_u8_DATA_PORT        DIO_u8_PORTA


#endif 
