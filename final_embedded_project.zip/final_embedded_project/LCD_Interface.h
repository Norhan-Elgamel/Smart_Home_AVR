/*
**************************** Author  : Mohamed Adel *****************************
**************************** Module  : LCD Driver   *****************************
**************************** Date    : 9/05/2021    *****************************
**************************** Version : 2.0          *****************************
*/
#ifndef LCD_INTERFACE_H
#define LCD_INTERFACE_H

#define LCD_u8_LINE1    0
#define LCD_u8_LINE2    1

#define CGRAM    		3

#define SIZE            6


void LCD_voidInit(void);
void LCD_voidSendCmnd(u8 Copy_u8Cmnd);
void LCD_voidSendChar(u8 Copy_u8Char);
void LCD_voidSendString(u8 *Copy_u8pName);
void LCD_voidSendNum(u32 Copy_u8Num);
void LCD_u8SetPosition(u8 Copy_u8LineNum , u8 Copy_u8Location);


#endif 
