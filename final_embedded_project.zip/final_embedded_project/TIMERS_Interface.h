/*
 * TIMERS_Interface.h
 *
 *  Created on: 29 Jul 2025
 *      Author: icon
 */

#ifndef TIMERS_INTERFACE_H_
#define TIMERS_INTERFACE_H_

/*Public Macros*/
#define    NORMAL_MODE      			                            0
#define    PWM_OR_PHASE_COTROL                                      1
#define    CTC_MODE                                                 2
#define    FAST_PWM_MODE                                            3

#define    NON_PWM_NORMAL_PORT_OPRETATION                           0
#define    NON_PWM_TOGGLE_OC0_ON_COMPARE_MATCH                      1
#define    NON_PWM_CLEAR_OC0_ON_COMPARE_MATCH                       2
#define    NON_PWM_SET_OC0_ON_COMPARE_MATCH						    3


#define    FAST_PWM_NORMAL_PORT_OPRETATION                          0
#define    FAST_PWM_CLEAR_OC0_ON_COMPARE_MATCH__SET_OC0_ON_TOP      1
#define    FAST_PWM_SET_OC0_ON_COMPARE_MATCH__CLEAR_OC0_ON_TOP	  	2


#define    CLK_DIV_BY_0										 	    1
#define    CLK_DIV_BY_8										 	    2
#define    CLK_DIV_BY_64                                            3
#define    CLK_DIV_BY_256                                           4
#define    CLK_DIV_BY_1024                                          5
#define    ECS_ON_T0_FALLING_EDGE      								6
#define    ECS_ON_T0_RISING_EDGE       								7

#define	   RISING_EDGE												0
#define	   FALLING_EDGE												1

/*********************************************************************************/
/*************************Public Functions Prototypes*****************************/
/*********************************************************************************/

/* Desc:This Function initializes Timer0							       	    **/
void TIMER_voidTimer0Init(void);

/* Desc:This Function Sets the compare value of timer 0					       	**/
void TIMER_voidTimer0SetCompareValue(u8 Copy_u8CompareValue);

/* Desc:This Function Sets the call back of Timer0							  	**/
void TIMER_voidTimer0SetCallBack(void (*Copy_pvNotificationFunction)(void));

/* Desc:This Function initializes Timer1							       	    **/
void TIMER_voidTimer1Init(void);


/*	Desc: Setting ICR1 value*/
void TIMER_voidTimer1SetICR1(u16 Copy_u16ICR_Value);

/* Desc:This Function Sets the compare value of timer 1 - A				       	**/
void TIMER_voidTimer1ASetCompareValue(u16 Copy_u16CompareValue);

/* Desc:This Function Sets the compare value of timer 1 - B				       	**/
void TIMER_voidTimer1BSetCompareValue(u16 Copy_u16CompareValue);


#endif /* TIMERS_INTERFACE_H_ */




















