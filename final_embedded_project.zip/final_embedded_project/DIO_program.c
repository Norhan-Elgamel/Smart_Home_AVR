/*
**************************** Author  : Mohamed Adel *****************************
**************************** Module  : DIO Driver   *****************************
**************************** Date    : 9/05/2021    *****************************
**************************** Version : 2.0          *****************************
*/

//includes of the source file in order

//LIB includes
#include "STD_TYPES.h"
#include "BIT_MATH.h"
//MCAL includes
#include "DIO_interface.h"
#include "DIO_private.h"
#include "DIO_config.h"


u8 DIO_u8SetPinDirection(u8 copy_u8PortId, u8 copy_u8PinId, u8 copy_u8PinDirection)
{
    u8 Local_u8ErrorState = STD_TYPES_OK;
    if((copy_u8PortId <= DIO_u8_PORTD) && (copy_u8PinId <= DIO_u8_PIN7) && (copy_u8PinDirection == DIO_u8_OUTPUT || copy_u8PinDirection == DIO_u8_INPUT))
    {
        switch(copy_u8PortId)
        {
            case DIO_u8_PORTA : 
                switch(copy_u8PinDirection)
                {
                    case DIO_u8_INPUT : CLR_BIT(DIO_u8_DDRA_REG,copy_u8PinId);break;
                    case DIO_u8_OUTPUT : SET_BIT(DIO_u8_DDRA_REG,copy_u8PinId);break;
                }
            break;
            case DIO_u8_PORTB : 
                switch(copy_u8PinDirection)
                {
                    case DIO_u8_INPUT : CLR_BIT(DIO_u8_DDRB_REG,copy_u8PinId);break;
                    case DIO_u8_OUTPUT : SET_BIT(DIO_u8_DDRB_REG,copy_u8PinId);break;
                }
            break;
            case DIO_u8_PORTC : 
                switch(copy_u8PinDirection)
                {
                    case DIO_u8_INPUT : CLR_BIT(DIO_u8_DDRC_REG,copy_u8PinId);break;
                    case DIO_u8_OUTPUT : SET_BIT(DIO_u8_DDRC_REG,copy_u8PinId);break;
                }
            break;
            case DIO_u8_PORTD : 
                switch(copy_u8PinDirection)
                {
                    case DIO_u8_INPUT : CLR_BIT(DIO_u8_DDRD_REG,copy_u8PinId);break;
                    case DIO_u8_OUTPUT : SET_BIT(DIO_u8_DDRD_REG,copy_u8PinId);break;
                }
            break;
        }
    }
    else
    {
        Local_u8ErrorState = STD_TYPES_NOK;
    }
    return Local_u8ErrorState ;
}
u8 DIO_u8SetPinValue(u8 copy_u8PortId, u8 copy_u8PinId, u8 copy_u8PinValue)
{
    u8 Local_u8ErrorState = STD_TYPES_OK;
    if((copy_u8PortId <= DIO_u8_PORTD) && (copy_u8PinId <= DIO_u8_PIN7) && (copy_u8PinValue == DIO_u8_HIGH || copy_u8PinValue == DIO_u8_LOW))
    {
        switch(copy_u8PortId)
        {
            case DIO_u8_PORTA : 
                switch(copy_u8PinValue)
                {
                    case DIO_u8_LOW : CLR_BIT(DIO_u8_PORTA_REG,copy_u8PinId);break;
                    case DIO_u8_HIGH : SET_BIT(DIO_u8_PORTA_REG,copy_u8PinId);break;
                }
            break;
            case DIO_u8_PORTB : 
                switch(copy_u8PinValue)
                {
                    case DIO_u8_LOW : CLR_BIT(DIO_u8_PORTB_REG,copy_u8PinId);break;
                    case DIO_u8_HIGH : SET_BIT(DIO_u8_PORTB_REG,copy_u8PinId);break;
                }
            break;
            case DIO_u8_PORTC : 
                switch(copy_u8PinValue)
                {
                    case DIO_u8_LOW : CLR_BIT(DIO_u8_PORTC_REG,copy_u8PinId);break;
                    case DIO_u8_HIGH : SET_BIT(DIO_u8_PORTC_REG,copy_u8PinId);break;
                }
            break;
            case DIO_u8_PORTD : 
                switch(copy_u8PinValue)
                {
                    case DIO_u8_LOW : CLR_BIT(DIO_u8_PORTD_REG,copy_u8PinId);break;
                    case DIO_u8_HIGH : SET_BIT(DIO_u8_PORTD_REG,copy_u8PinId);break;
                }
            break;
        }
    }
    else
    {
        Local_u8ErrorState = STD_TYPES_NOK;
    }

    return Local_u8ErrorState;

}
u8 DIO_u8GetPinValue(u8 copy_u8PortId, u8 copy_u8PinId, u8 * copy_pu8PinValue)
{
    u8 Local_u8ErrorState = STD_TYPES_OK;
    u8 Local_u8PinValue;
    if((copy_u8PortId <= DIO_u8_PORTD) && (copy_u8PinId <= DIO_u8_PIN7) && (copy_pu8PinValue != NULL))
    {
        switch(copy_u8PortId)
        {
            case DIO_u8_PORTA : 
                Local_u8PinValue = GET_BIT(DIO_u8_PINA_REG,copy_u8PinId);
                if(Local_u8PinValue == 0)
                {
                    *copy_pu8PinValue = DIO_u8_LOW;
                }
                else
                {
                    *copy_pu8PinValue = DIO_u8_HIGH;
                }
            break;
            case DIO_u8_PORTB : 
                Local_u8PinValue = GET_BIT(DIO_u8_PINB_REG,copy_u8PinId);
                if(Local_u8PinValue == 0)
                {
                    *copy_pu8PinValue = DIO_u8_LOW;
                }
                else
                {
                    *copy_pu8PinValue = DIO_u8_HIGH;
                }
            break;
            case DIO_u8_PORTC :  
                Local_u8PinValue = GET_BIT(DIO_u8_PINC_REG,copy_u8PinId);
                if(Local_u8PinValue == 0)
                {
                    *copy_pu8PinValue = DIO_u8_LOW;
                }
                else
                {
                    *copy_pu8PinValue = DIO_u8_HIGH;
                }
            break;
            case DIO_u8_PORTD : 
                Local_u8PinValue = GET_BIT(DIO_u8_PIND_REG,copy_u8PinId);
                if(Local_u8PinValue == 0)
                {
                    *copy_pu8PinValue = DIO_u8_LOW;
                }
                else
                {
                    *copy_pu8PinValue = DIO_u8_HIGH;
                }
            break;
        }
    }
    else
    {
        Local_u8ErrorState = STD_TYPES_NOK;
    }
    return Local_u8ErrorState;
}
u8 DIO_u8SetPortDirection(u8 copy_u8PortId, u8 copy_u8PortDirection)
{
    u8 Local_u8ErrorState = STD_TYPES_OK;

    if((copy_u8PortId <= DIO_u8_PORTD))
    {
        switch(copy_u8PortId)
        {
            case DIO_u8_PORTA : 
                switch(copy_u8PortDirection)
                {
                    case DIO_u8_INPUT : DIO_u8_DDRA_REG = 0x00;break;
                    case DIO_u8_OUTPUT : DIO_u8_DDRA_REG = 0xFF;break;
                    default :DIO_u8_DDRA_REG = copy_u8PortDirection;
                }
            break;
            case DIO_u8_PORTB : 
                switch(copy_u8PortDirection)
                {
                    case DIO_u8_INPUT : DIO_u8_DDRB_REG = 0x00 ;break;
                    case DIO_u8_OUTPUT : DIO_u8_DDRB_REG = 0XFF ;break;
                    default :DIO_u8_DDRB_REG = copy_u8PortDirection;
                }
            break;
            case DIO_u8_PORTC : 
                switch(copy_u8PortDirection)
                {
                    case DIO_u8_INPUT : DIO_u8_DDRC_REG = 0x00;break;
                    case DIO_u8_OUTPUT : DIO_u8_DDRC_REG = 0xFF;break;
                    default :DIO_u8_DDRC_REG = copy_u8PortDirection;
                }
            break;
            case DIO_u8_PORTD : 
                switch(copy_u8PortDirection)
                {
                    case DIO_u8_INPUT : DIO_u8_DDRD_REG = 0x00;break;
                    case DIO_u8_OUTPUT : DIO_u8_DDRD_REG = 0xFF ;break;
                    default :DIO_u8_DDRD_REG = copy_u8PortDirection;
                }
            break;
        }
    }
    else
    {
        Local_u8ErrorState = STD_TYPES_NOK;
    }
    return Local_u8ErrorState;
}
u8 DIO_u8SetPortValue(u8 copy_u8PortId, u8 copy_u8PortValue)
{
    u8 Local_u8ErrorState = STD_TYPES_OK;
    if((copy_u8PortId <= DIO_u8_PORTD) )
    {
        switch(copy_u8PortId)
        {
            case DIO_u8_PORTA : 
            	switch(copy_u8PortValue)
            	{
            	case DIO_u8_LOW : DIO_u8_PORTA_REG = 0x00 ;break;
            	case DIO_u8_HIGH : DIO_u8_PORTA_REG = 0xFF;break;
            	default : DIO_u8_PORTA_REG = copy_u8PortValue;
            	}
            break;
            case DIO_u8_PORTB :
            	switch(copy_u8PortValue)
            	{
            	case DIO_u8_LOW : DIO_u8_PORTB_REG = 0x00 ;break;
            	case DIO_u8_HIGH : DIO_u8_PORTB_REG = 0xFF;break;
            	default : DIO_u8_PORTB_REG = copy_u8PortValue;
            	}
            break;
            case DIO_u8_PORTC :
            	switch(copy_u8PortValue)
            	{
            	case DIO_u8_LOW : DIO_u8_PORTC_REG = 0x00 ;break;
            	case DIO_u8_HIGH : DIO_u8_PORTC_REG = 0xFF;break;
            	default : DIO_u8_PORTC_REG = copy_u8PortValue;
            	}
            break;
            case DIO_u8_PORTD : 
            	switch(copy_u8PortValue)
            	{
            	case DIO_u8_LOW : DIO_u8_PORTD_REG = 0x00 ;break;
            	case DIO_u8_HIGH : DIO_u8_PORTD_REG = 0xFF;break;
            	default : DIO_u8_PORTD_REG = copy_u8PortValue;
            	}
            break;
        }
    }
    else
    {
        Local_u8ErrorState = STD_TYPES_NOK;
    }
    return Local_u8ErrorState;
}
u8 DIO_u8GetPortValue(u8 copy_u8PortId, u8 * copy_pu8PortValue)
{
    u8 Local_u8ErrorState = STD_TYPES_OK;
    if((copy_u8PortId <= DIO_u8_PORTD) && (copy_pu8PortValue != NULL))
    {
        switch(copy_u8PortId)
        {
            case DIO_u8_PORTA : 
                *copy_pu8PortValue = DIO_u8_PINA_REG;
                break;
            case DIO_u8_PORTB : 
                *copy_pu8PortValue = DIO_u8_PINB_REG;
                break;
            case DIO_u8_PORTC : 
                *copy_pu8PortValue = DIO_u8_PINC_REG;
                break;
            case DIO_u8_PORTD : 
                *copy_pu8PortValue = DIO_u8_PIND_REG;
                break;
        }
    }
    else
    {
        Local_u8ErrorState = STD_TYPES_NOK;
    }

    return Local_u8ErrorState;

}
