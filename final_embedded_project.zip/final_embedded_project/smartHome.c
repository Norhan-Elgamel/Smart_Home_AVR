#define F_CPU 8000000UL
#include <util/delay.h>
#include "STD_TYPES.h"
#include "DIO_interface.h"
#include "LCD_Interface.h"
#include"Stepper_Config.h"
#include"Stepper_Interface.h"
#include "TIMERS_Interface.h"

int main(void)
{
    u8 pinValue;

    LCD_voidInit();

    // Set PC1 as input and enable internal pull-up resistor
    DIO_u8SetPinDirection(DIO_u8_PORTC, DIO_u8_PIN1, DIO_u8_INPUT);
    DIO_u8SetPinValue(DIO_u8_PORTC, DIO_u8_PIN1, DIO_u8_HIGH);
    DIO_u8SetPinDirection(DIO_u8_PORTB, DIO_u8_PIN2, DIO_u8_OUTPUT);
    DIO_u8SetPinDirection(DIO_u8_PORTD, DIO_u8_PIN4, DIO_u8_OUTPUT);


                // Buzzer output pin
                DIO_u8SetPinDirection(DIO_u8_PORTC, DIO_u8_PIN0, DIO_u8_OUTPUT);

    TIMER_voidTimer0Init();
    STP_voidInit();
    u8 numbers[10] = {
                     0b11000000, // 0
                     0b11111001, // 1
                     0b10100100, // 2
                     0b10110000, // 3
                     0b10011001, // 4
                     0b10010010, // 5
                     0b10000010, // 6
                     0b11111000, // 7
                     0b10000000, // 8
                     0b10010000  // 9
                   };
    while(1)
    {
        DIO_u8GetPinValue(DIO_u8_PORTC, DIO_u8_PIN1, &pinValue);


        if(pinValue == 1)
{
        	LCD_u8SetPosition(LCD_u8_LINE1, 0);
        	char t[]="Welcome Home";
        	LCD_voidSendString(t);

        DIO_u8SetPinDirection(DIO_u8_PORTB, DIO_u8_PIN3, DIO_u8_OUTPUT);

            // Buzzer output pin
            DIO_u8SetPinDirection(DIO_u8_PORTB, DIO_u8_PIN5, DIO_u8_OUTPUT);
            DIO_u8SetPinValue(DIO_u8_PORTB, DIO_u8_PIN5, DIO_u8_HIGH);
            _delay_ms(2000);
            DIO_u8SetPinValue(DIO_u8_PORTB, DIO_u8_PIN5, DIO_u8_LOW);


                // Servo at 0 degrees
                TIMER_voidTimer0SetCompareValue(200);
                DIO_u8SetPinValue(DIO_u8_PORTD, DIO_u8_PIN4, DIO_u8_HIGH); // Buzzer ON
                _delay_ms(1000);

                // Servo at 90 degrees
                TIMER_voidTimer0SetCompareValue(90);
                DIO_u8SetPinValue(DIO_u8_PORTD, DIO_u8_PIN4, DIO_u8_LOW);  // Buzzer OFF
                _delay_ms(1000);

                // Servo at 180 degrees
                TIMER_voidTimer0SetCompareValue(200);
                DIO_u8SetPinValue(DIO_u8_PORTD, DIO_u8_PIN4, DIO_u8_HIGH); // Buzzer ON
                _delay_ms(1000);

                // Back to center
                TIMER_voidTimer0SetCompareValue(90);
                DIO_u8SetPinValue(DIO_u8_PORTD, DIO_u8_PIN4, DIO_u8_LOW);  // Buzzer OFF
                _delay_ms(1000);

               /* STP_voidMove(1);
                _delay_ms(2000);
                STP_voidMove(0);
                _delay_ms(2000);
                STP_voidMove( STOP );*/
			DIO_u8SetPinValue( DIO_u8_PORTD ,DIO_u8_PIN0, DIO_u8_LOW );
			DIO_u8SetPinValue( DIO_u8_PORTD ,DIO_u8_PIN1, DIO_u8_HIGH );
			DIO_u8SetPinValue( DIO_u8_PORTD ,DIO_u8_PIN2, DIO_u8_HIGH );
			DIO_u8SetPinValue( DIO_u8_PORTD ,DIO_u8_PIN3, DIO_u8_HIGH );
			DIO_u8SetPinValue( DIO_u8_PORTD ,DIO_u8_PIN4, DIO_u8_HIGH );
			DIO_u8SetPinValue( DIO_u8_PORTD ,DIO_u8_PIN5, DIO_u8_HIGH );
			DIO_u8SetPinValue( DIO_u8_PORTD ,DIO_u8_PIN6, DIO_u8_HIGH );

                DIO_u8SetPortDirection( DIO_u8_PORTC , DIO_u8_OUTPUT );
                DIO_u8SetPortValue(DIO_u8_PORTC,DIO_u8_HIGH   );

                       /* for (s8 i = 9; i>=0; i--)
                        {
                            //DIO_u8SetPortValue(DIO_u8_PORTC,numbers[i]);
                        	DIO_u8SetPortValue(DIO_u8_PORTC, 0b11111110); // Turn on only segment a (assuming active low)
                        	_delay_ms(1000);
                        	DIO_u8SetPortValue(DIO_u8_PORTC, 0xFF);

                            _delay_ms(500);

                        }*/
                       }







        else if(pinValue == 0)
            {
        	LCD_u8SetPosition(LCD_u8_LINE1, 0);
        	LCD_voidSendString("               ");}

        _delay_ms(200);
    }
}
