/*
 * TIMERS_Program.c
 *
 *  Created on: 29 Jul 2025
 *      Author: icon
 */

#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "TIMERS_Interface.h"
#include "TIMERS_Private.h"
#include "TIMERS_Config.h"


void (* TIMER_pvTimer0NotificationFunction)(void) = NULL;

/**********************		Timer 0	Functions		******************************/

/* Desc:This Function initializes Timer0							       	    **/
void TIMER_voidTimer0Init(void){

	#if WAVEFORM_GEN_MODE == NORMAL_MODE
	/*Set Timer 0 in NORMAL_MODE*/
	CLR_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_WGM00);
	CLR_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_WGM01);

	#elif WAVEFORM_GEN_MODE == PWM_OR_PHASE_COTROL
	/*Set Timer 0 in PWM_OR_PHASE_COTROL Mode*/
	SET_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_WGM00);
	CLR_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_WGM01);

	#elif WAVEFORM_GEN_MODE == CTC_MODE
	/*Set Timer 0 in CTC_MODE*/
	CLR_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_WGM00);
	SET_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_WGM01);
	switch(OC0_ACTION)
	{
		case NON_PWM_NORMAL_PORT_OPRETATION:				/*Normal Port Operation*/
			CLR_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_COM00);
			CLR_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_COM01);
			break;
		case NON_PWM_TOGGLE_OC0_ON_COMPARE_MATCH:	        /*Toggle OC0 on Compare Match*/
			SET_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_COM00);
			CLR_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_COM01);
			break;
		case NON_PWM_CLEAR_OC0_ON_COMPARE_MATCH:	        /*Clear OC0 on Compare Match*/
			CLR_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_COM00);
			SET_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_COM01);
			break;
		case NON_PWM_SET_OC0_ON_COMPARE_MATCH:	            /*Set OC0 on Compare Match*/
			SET_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_COM00);
			SET_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_COM01);
			break;
		default: break;
	}

	#elif WAVEFORM_GEN_MODE == FAST_PWM_MODE
	/*Set Timer 0 in FAST_PWM_MODE*/
	SET_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_WGM00);
	SET_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_WGM01);
	switch(OC0_ACTION)
	{
	case FAST_PWM_NORMAL_PORT_OPRETATION:						/*Normal Port Operation*/
		CLR_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_COM00);
		CLR_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_COM01);
		break;
	case FAST_PWM_CLEAR_OC0_ON_COMPARE_MATCH__SET_OC0_ON_TOP:	/*Set The "Clear On Compare, Sets On TOP" Mode (Non-Inverted)*/
		CLR_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_COM00);
		SET_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_COM01);
		break;
	case FAST_PWM_SET_OC0_ON_COMPARE_MATCH__CLEAR_OC0_ON_TOP:	/*Set The "Set On Compare, Clear On TOP" Mode (Inverted)*/
		SET_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_COM00);
		SET_BIT(TIM0_u8_TCCR0_REG, TIM0_u8_TCCR0_COM01);
		break;
	default: break;
	}
	#endif

	/*Set The Prescaler to be 8*/
	TIM0_u8_TCCR0_REG &= PRESCALER_MASK;
	TIM0_u8_TCCR0_REG |= PRESCALER_TYPE;
}

/* Desc:This Function Sets the compare value of timer 0					       	**/
void TIMER_voidTimer0SetCompareValue(u8 Copy_u8CompareValue)
{
	/*Set The Compare Value to the OCR0 Register*/
	TIM0_u8_OCR0_REG = Copy_u8CompareValue;
}

/* Desc:This Function Sets the call back of Timer0							  	**/
void TIMER_voidTimer0SetCallBack(void (*Copy_pvNotificationFunction)(void))
{
	/*Assign the function address to the global pointer to function*/
	TIMER_pvTimer0NotificationFunction = Copy_pvNotificationFunction;
}


/***********************************Timer0 ISR forCompare Match Event***********************************/
void __vector_10 (void) __attribute__((signal));
void __vector_10 (void)
{
	/*Check if the global pointer to function is changed or not*/
	if(TIMER_pvTimer0NotificationFunction != NULL)
	{
		/*Execute the global pointer to function*/
		TIMER_pvTimer0NotificationFunction();
	}
}

/***********************************Timer0 ISR for OverFlow Event***********************************/
void __vector_11 (void) __attribute__((signal));
void __vector_11 (void)
{
	/*Check if the global pointer to function is changed or not*/
	if(TIMER_pvTimer0NotificationFunction != NULL){
		/*Execute the global pointer to function*/
		TIMER_pvTimer0NotificationFunction();
	}
}
