GPI_program.o GPI_program.o: ../GPI_program.c ../STD_TYPES.h \
  ../BIT_MATH.h ../GPI_Interface.h ../GPI_Private.h ../GPI_Config.h

../STD_TYPES.h:

../BIT_MATH.h:

../GPI_Interface.h:

../GPI_Private.h:

../GPI_Config.h:
