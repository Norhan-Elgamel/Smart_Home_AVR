################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ADC_Program.c \
../DIO_program.c \
../GPI_program.c \
../LCD_program.c \
../Stepper_Program.c \
../TIMERS_Program.c \
../app.c \
../smartHome.c 

OBJS += \
./ADC_Program.o \
./DIO_program.o \
./GPI_program.o \
./LCD_program.o \
./Stepper_Program.o \
./TIMERS_Program.o \
./app.o \
./smartHome.o 

C_DEPS += \
./ADC_Program.d \
./DIO_program.d \
./GPI_program.d \
./LCD_program.d \
./Stepper_Program.d \
./TIMERS_Program.d \
./app.d \
./smartHome.d 


# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.c
	@echo 'Building file: $<'
	@echo 'Invoking: AVR Compiler'
	avr-gcc -Wall -g2 -gstabs -O0 -fpack-struct -fshort-enums -ffunction-sections -fdata-sections -std=gnu99 -funsigned-char -funsigned-bitfields -mmcu=atmega32 -DF_CPU=8000000UL -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


