smartHome.o smartHome.o: ../smartHome.c ../STD_TYPES.h ../DIO_interface.h \
  ../LCD_Interface.h ../Stepper_Config.h ../Stepper_Interface.h \
  ../TIMERS_Interface.h

../STD_TYPES.h:

../DIO_interface.h:

../LCD_Interface.h:

../Stepper_Config.h:

../Stepper_Interface.h:

../TIMERS_Interface.h:
