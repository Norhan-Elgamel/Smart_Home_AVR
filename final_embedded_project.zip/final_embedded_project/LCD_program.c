/*
**************************** Author  : Mohamed Adel *****************************
**************************** Module  : LCD Driver   *****************************
**************************** Date    : 9/05/2021    *****************************
**************************** Version : 2.0          *****************************
*/
//LIB layer
#include "STD_TYPES.h"
#include "BIT_MATH.h"
#define F_CPU      8000000UL
#include <util/delay.h>
//MCAL Layer
#include "DIO_interface.h"
//HAL Layer
#include "LCD_config.h"
#include "LCD_Interface.h"
#include "LCD_private.h"


void LCD_voidInit(void)
{

	//setting pins direction for control and data pins
	DIO_u8SetPortDirection(LCD_u8_CONTROL_PORT, DIO_u8_OUTPUT);

	DIO_u8SetPortDirection(LCD_u8_DATA_PORT, DIO_u8_OUTPUT);

	//initialize control and data pins values
	DIO_u8SetPortValue(LCD_u8_CONTROL_PORT, DIO_u8_LOW);
	DIO_u8SetPortValue(LCD_u8_DATA_PORT, DIO_u8_LOW);

    //steps from the datasheet for 8-bit initialization
    //delay > 30ms
    _delay_ms(35);
    
    //command from DB7 to DB0 ---> 0,0,1,1,N,F,X,X
    //DB4 is 1 for 8-bit init or 0 for 4-bit init
    //N in DB3 stands for number of lines : set n with 1 for 2-line display and 0 for 1 line display
    //F in DB2 stands for the character font (pixels) : f=0 for 5x7 dots and f=1 for 5x10 dots
    //------------- function set command --------------------
    LCD_voidSendCmnd(0b00111000);
    //delay >  39 us
    _delay_us(40);
    LCD_voidSendCmnd(0b00001111);
    //delay >  39 us
    _delay_us(40);
    //clear display command
    LCD_voidSendCmnd(0b00000001);
    //delay >  1.53 ms
    _delay_ms(2); 
    //entry mode set
    LCD_voidSendCmnd(0b00000110);
}
void LCD_voidSendCmnd(u8 Copy_u8Cmnd)
{
    //step1 Rs = 0
    DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_RS_PIN,DIO_u8_LOW);
    //Rw = 0
    DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_RW_PIN,DIO_u8_LOW);
    //write command
    DIO_u8SetPortValue(LCD_u8_DATA_PORT,Copy_u8Cmnd);
    // E = 1
    DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_E_PIN,DIO_u8_HIGH);
    _delay_us(1);
    // E = 0
    DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_E_PIN,DIO_u8_LOW);

}
void LCD_voidSendChar(u8 Copy_u8Char)
{
    //step1 Rs = 1
    DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_RS_PIN,DIO_u8_HIGH);
    //Rw = 0
    DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_RW_PIN,DIO_u8_LOW);
    //write command
    DIO_u8SetPortValue(LCD_u8_DATA_PORT,Copy_u8Char);
    // E = 1
    DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_E_PIN,DIO_u8_HIGH);
    _delay_us(1);
    // E = 0
    DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_E_PIN,DIO_u8_LOW);

}
void LCD_voidSendString(u8 *Copy_u8pName)
{
		//step1 Rs = 1
	    DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_RS_PIN,DIO_u8_HIGH);
	    //Rw = 0
	    DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_RW_PIN,DIO_u8_LOW);
	    while(*Copy_u8pName != '\0')
	    {
	    	//write command
	    	DIO_u8SetPortValue(LCD_u8_DATA_PORT,*Copy_u8pName);
	    	// E = 1
	    	DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_E_PIN,DIO_u8_HIGH);
	    	_delay_us(1);
	    	// E = 0
	    	DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_E_PIN,DIO_u8_LOW);
	    	Copy_u8pName++;
	    }
}
void LCD_voidSendNum(u32 Copy_u8Num)
{
	    //step1 Rs = 1
		DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_RS_PIN,DIO_u8_HIGH);
		//Rw = 0
		DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_RW_PIN,DIO_u8_LOW);

		u32 num = Copy_u8Num;
		u8 remainder;
		u8 array[10];
		u8 i = 0;
		u8 size = 0;

	    while(num != 0)
	    {
	    	if((num%10) == 0)
	    	{
	    		remainder = 0;
	    	}
	    	else
	    	{
	    		remainder = num%10;
	    	}
	    	num = num/10;
	    	array[i] = remainder + 48;
	    	i++;
	    	size++;
	    }
	    for(int k = size-1 ; k >= 0 ; k--)
	   	{
	   		DIO_u8SetPortValue(LCD_u8_DATA_PORT,array[k]);
	   		DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_E_PIN,DIO_u8_HIGH);
	   		_delay_us(1);
	   		DIO_u8SetPinValue(LCD_u8_CONTROL_PORT,LCD_u8_E_PIN,DIO_u8_LOW);
	   	}
}
void LCD_u8SetPosition(u8 Copy_u8LineNum , u8 Copy_u8Location)
{

	if(Copy_u8Location >= 0 && Copy_u8Location <= 39)
	{
		switch(Copy_u8LineNum)
		{
			case LCD_u8_LINE1:LCD_voidSendCmnd(DDRAM_2x16_L1SA|Copy_u8Location);break;
			case LCD_u8_LINE2:LCD_voidSendCmnd(DDRAM_2x16_L2SA|Copy_u8Location);break;
			default : LCD_voidSendCmnd(0x40|Copy_u8Location);
		}
	}

}
