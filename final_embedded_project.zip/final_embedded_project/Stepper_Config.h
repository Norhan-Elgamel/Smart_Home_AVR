/***************************************************************************************/
/****************************  IMT School Training Center ******************************/
/***************************************************************************************/
/** This file is developed by IMT School training center, All copyrights are reserved **/
/***************************************************************************************/
#ifndef STP_CONFIG_H_
#define STP_CONFIG_H_

#define STP_u8_PORT					 DIO_u8_PORTD


#define CLOCKWISE_DIRECTION        1
#define COUNTER_CLOCKWISE_DIRECTION  0
#define STOP                         2

#endif /* STP_CONFIG_H_ */
